package com.smhrd.model;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import com.smhrd.database.SqlSessionManager;

public class MemberDAO {

	SqlSessionFactory sessionFactory = SqlSessionManager.getSqlSessionFactory();

	public int join(MemberVO member) {
		SqlSession sqlSession = sessionFactory.openSession(true);
	
		int res = sqlSession.insert("com.smhrd.database.MemberMapper.join", member);
		sqlSession.close();
		return res;

	}

}
